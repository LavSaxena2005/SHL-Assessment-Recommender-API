"""
Utility functions for the SHL Recommender system.
"""

import json
import logging
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

CATALOG_PATH = Path(__file__).parent.parent / "catalog" / "catalog.json"


def load_catalog(path: Optional[Path] = None) -> list[dict]:
    """Load the SHL catalog from JSON file."""
    p = path or CATALOG_PATH
    if not p.exists():
        raise FileNotFoundError(
            f"Catalog not found at {p}. "
            "Run: python -m app.scraper.scraper"
        )
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def get_catalog_summary() -> dict:
    """Return a summary of the catalog for diagnostics."""
    catalog = load_catalog()
    by_type = {}
    by_category = {}

    for a in catalog:
        t = a.get("test_type", "?")
        by_type[t] = by_type.get(t, 0) + 1
        c = a.get("category", "Unknown")
        by_category[c] = by_category.get(c, 0) + 1

    return {
        "total": len(catalog),
        "by_test_type": by_type,
        "by_category": by_category,
    }


def validate_catalog() -> list[str]:
    """Validate catalog entries and return list of warnings."""
    catalog = load_catalog()
    warnings = []

    for i, a in enumerate(catalog):
        if not a.get("name"):
            warnings.append(f"Entry {i}: missing name")
        if not a.get("url"):
            warnings.append(f"Entry {i} ({a.get('name')}): missing URL")
        if not a.get("description"):
            warnings.append(f"Entry {i} ({a.get('name')}): missing description")
        if a.get("test_type") not in ("A", "P", "K", "S", "B", "W"):
            warnings.append(
                f"Entry {i} ({a.get('name')}): invalid test_type '{a.get('test_type')}'"
            )

    return warnings
