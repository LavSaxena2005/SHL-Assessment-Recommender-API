"""
Pydantic models for request/response validation.
"""

from typing import Literal, Optional
from pydantic import BaseModel, Field, field_validator


class Message(BaseModel):
    """A single conversation message."""
    role: Literal["user", "assistant"]
    content: str = Field(..., min_length=1, max_length=4000)


class ChatRequest(BaseModel):
    """Incoming chat request with full conversation history."""
    messages: list[Message] = Field(..., min_length=1, max_length=20)

    @field_validator("messages")
    @classmethod
    def validate_messages(cls, msgs: list[Message]) -> list[Message]:
        if not msgs:
            raise ValueError("At least one message required")
        if msgs[-1].role != "user":
            raise ValueError("Last message must be from user")
        return msgs


class AssessmentRecommendation(BaseModel):
    """A single recommended assessment."""
    name: str
    url: str
    test_type: str = Field(..., description="A=Ability, P=Personality, K=Knowledge, S=Situational, B=Biodata, W=Work Sample")


class ChatResponse(BaseModel):
    """API response with reply, recommendations, and conversation state."""
    reply: str
    recommendations: list[AssessmentRecommendation] = Field(default_factory=list)
    end_of_conversation: bool = False


class HealthResponse(BaseModel):
    """Health check response."""
    status: str = "ok"


class Assessment(BaseModel):
    """Full assessment record from catalog."""
    name: str
    url: str
    description: str = ""
    category: str = ""
    skills: list[str] = Field(default_factory=list)
    duration: Optional[int] = None
    test_type: str = "K"

    def to_text(self) -> str:
        """Serialize to text for embedding and BM25."""
        skills_str = ", ".join(self.skills) if self.skills else ""
        duration_str = f"{self.duration} minutes" if self.duration else ""
        parts = [
            f"Assessment: {self.name}",
            f"Category: {self.category}",
            f"Description: {self.description}",
            f"Skills: {skills_str}",
            f"Duration: {duration_str}",
            f"Test Type: {self.test_type}",
        ]
        return " | ".join(p for p in parts if p.split(": ", 1)[1])
