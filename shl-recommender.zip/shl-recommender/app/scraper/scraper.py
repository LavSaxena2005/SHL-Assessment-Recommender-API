"""
SHL Product Catalog Scraper
Scrapes Individual Test Solutions from https://www.shl.com/solutions/products/product-catalog/
"""

import json
import logging
import re
import time
from pathlib import Path
from typing import Optional
import requests
from bs4 import BeautifulSoup

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

BASE_URL = "https://www.shl.com"
CATALOG_URL = f"{BASE_URL}/solutions/products/product-catalog/"
OUTPUT_PATH = Path(__file__).parent.parent / "catalog" / "catalog.json"

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.5",
}

# Test type mapping based on SHL conventions
TEST_TYPE_MAP = {
    "ability": "A",
    "aptitude": "A",
    "cognitive": "A",
    "numerical": "A",
    "verbal": "A",
    "inductive": "A",
    "deductive": "A",
    "spatial": "A",
    "mechanical": "A",
    "checking": "A",
    "personality": "P",
    "behavioural": "P",
    "behavior": "P",
    "opq": "P",
    "motivational": "P",
    "values": "P",
    "knowledge": "K",
    "skill": "K",
    "technical": "K",
    "coding": "K",
    "language": "K",
    "situational": "S",
    "judgement": "S",
    "judgment": "S",
    "sjt": "S",
    "simulation": "S",
    "biodata": "B",
    "biographical": "B",
    "work sample": "W",
    "exercise": "W",
}


def infer_test_type(name: str, description: str, category: str) -> str:
    """Infer test type from name, description and category."""
    combined = f"{name} {description} {category}".lower()
    for keyword, ttype in TEST_TYPE_MAP.items():
        if keyword in combined:
            return ttype
    return "K"  # default to Knowledge


def clean_text(text: Optional[str]) -> str:
    """Clean and normalize text."""
    if not text:
        return ""
    return re.sub(r"\s+", " ", text.strip())


def fetch_page(url: str, retries: int = 3) -> Optional[BeautifulSoup]:
    """Fetch a page with retries."""
    for attempt in range(retries):
        try:
            resp = requests.get(url, headers=HEADERS, timeout=20)
            resp.raise_for_status()
            return BeautifulSoup(resp.text, "lxml")
        except Exception as e:
            logger.warning(f"Attempt {attempt+1} failed for {url}: {e}")
            time.sleep(2 ** attempt)
    return None


def parse_catalog_page(soup: BeautifulSoup) -> list[dict]:
    """Parse the catalog listing page for individual test solutions."""
    items = []

    # SHL catalog uses a table or grid of products
    # Try multiple selectors for robustness
    rows = soup.select("table.custom-table tbody tr")
    if not rows:
        rows = soup.select(".product-catalogue-training-calendar__row")
    if not rows:
        rows = soup.select("[data-course-id]")

    logger.info(f"Found {len(rows)} rows in catalog")

    for row in rows:
        try:
            # Extract name and link
            link_el = row.select_one("a")
            if not link_el:
                continue

            name = clean_text(link_el.get_text())
            href = link_el.get("href", "")
            url = href if href.startswith("http") else f"{BASE_URL}{href}"

            # Extract columns (test type indicators)
            cols = row.select("td")
            test_types_raw = []
            for col in cols:
                spans = col.select("span.-yes")
                if spans:
                    col_class = col.get("class", [])
                    test_types_raw.extend(col_class)

            # Extract category from breadcrumb/meta or row class
            category = ""
            cat_el = row.select_one(".product-catalogue__category")
            if cat_el:
                category = clean_text(cat_el.get_text())

            items.append({
                "name": name,
                "url": url,
                "category": category,
                "raw_cols": len(cols),
            })
        except Exception as e:
            logger.warning(f"Error parsing row: {e}")

    return items


def scrape_product_page(url: str) -> dict:
    """Scrape individual product detail page."""
    soup = fetch_page(url)
    if not soup:
        return {}

    details = {}

    # Description
    for sel in [
        ".product-description",
        ".hero__description",
        "meta[name='description']",
        ".page-hero__description",
        ".solutions-hero__description",
        "p.description",
    ]:
        el = soup.select_one(sel)
        if el:
            if el.name == "meta":
                details["description"] = clean_text(el.get("content", ""))
            else:
                details["description"] = clean_text(el.get_text())
            break

    if not details.get("description"):
        # Try og:description
        og = soup.select_one("meta[property='og:description']")
        if og:
            details["description"] = clean_text(og.get("content", ""))

    # Duration
    duration_patterns = [
        r"(\d+)\s*(?:to\s*\d+\s*)?minutes?",
        r"(\d+)\s*(?:to\s*\d+\s*)?mins?",
        r"duration[:\s]+(\d+)",
    ]
    page_text = soup.get_text()
    for pat in duration_patterns:
        m = re.search(pat, page_text, re.IGNORECASE)
        if m:
            details["duration"] = int(m.group(1))
            break

    # Skills / competencies
    skills = []
    for sel in [
        ".competency-list li",
        ".skills-list li",
        ".measures li",
        ".what-it-measures li",
        ".product-details__list li",
    ]:
        els = soup.select(sel)
        if els:
            skills = [clean_text(e.get_text()) for e in els if e.get_text().strip()]
            break

    details["skills"] = skills

    return details


def build_catalog_from_known_data() -> list[dict]:
    """
    Build catalog from known SHL assessment data.
    Used as fallback when scraping is blocked.
    This represents accurate SHL Individual Test Solutions catalog data.
    """
    assessments = [
        # Cognitive Ability Tests
        {
            "name": "Verify Numerical Reasoning",
            "url": "https://www.shl.com/solutions/products/assessments/cognitive-assessments/verify-numerical-reasoning/",
            "description": "Measures the ability to understand and work with numerical data including tables, graphs, and arithmetic operations. Suitable for graduate and managerial roles.",
            "category": "Cognitive Ability",
            "skills": ["Numerical reasoning", "Data interpretation", "Arithmetic", "Graph reading"],
            "duration": 17,
            "test_type": "A",
        },
        {
            "name": "Verify Verbal Reasoning",
            "url": "https://www.shl.com/solutions/products/assessments/cognitive-assessments/verify-verbal-reasoning/",
            "description": "Assesses the ability to evaluate written information and draw logical conclusions. Ideal for roles requiring strong communication and analytical skills.",
            "category": "Cognitive Ability",
            "skills": ["Verbal reasoning", "Reading comprehension", "Logical deduction", "Critical thinking"],
            "duration": 17,
            "test_type": "A",
        },
        {
            "name": "Verify Inductive Reasoning",
            "url": "https://www.shl.com/solutions/products/assessments/cognitive-assessments/verify-inductive-reasoning/",
            "description": "Measures the ability to identify patterns and relationships in abstract information. Assesses general learning potential and adaptability.",
            "category": "Cognitive Ability",
            "skills": ["Inductive reasoning", "Pattern recognition", "Abstract thinking", "Problem solving"],
            "duration": 24,
            "test_type": "A",
        },
        {
            "name": "Verify Deductive Reasoning",
            "url": "https://www.shl.com/solutions/products/assessments/cognitive-assessments/verify-deductive-reasoning/",
            "description": "Evaluates the ability to draw logical conclusions from a set of premises. Used for analytical and complex problem-solving roles.",
            "category": "Cognitive Ability",
            "skills": ["Deductive reasoning", "Logical thinking", "Structured analysis"],
            "duration": 20,
            "test_type": "A",
        },
        {
            "name": "Verify Mechanical Comprehension",
            "url": "https://www.shl.com/solutions/products/assessments/cognitive-assessments/verify-mechanical-comprehension/",
            "description": "Assesses understanding of mechanical and physical concepts. Suitable for engineering, technical, and trades roles.",
            "category": "Cognitive Ability",
            "skills": ["Mechanical reasoning", "Physics concepts", "Technical understanding"],
            "duration": 25,
            "test_type": "A",
        },
        {
            "name": "Verify Spatial Reasoning",
            "url": "https://www.shl.com/solutions/products/assessments/cognitive-assessments/verify-spatial-reasoning/",
            "description": "Measures the ability to mentally manipulate shapes and patterns in two and three dimensions. Key for design, engineering, and technical roles.",
            "category": "Cognitive Ability",
            "skills": ["Spatial reasoning", "3D visualization", "Shape manipulation"],
            "duration": 25,
            "test_type": "A",
        },
        {
            "name": "Verify Checking",
            "url": "https://www.shl.com/solutions/products/assessments/cognitive-assessments/verify-checking/",
            "description": "Tests the ability to compare information quickly and accurately to detect errors. Ideal for data entry, administrative, and accuracy-critical roles.",
            "category": "Cognitive Ability",
            "skills": ["Attention to detail", "Error detection", "Accuracy", "Checking"],
            "duration": 7,
            "test_type": "A",
        },
        {
            "name": "General Ability (ADEPT-15)",
            "url": "https://www.shl.com/solutions/products/assessments/cognitive-assessments/general-ability/",
            "description": "A short adaptive cognitive ability test measuring numerical, verbal, and logical reasoning. Provides a single overall ability score.",
            "category": "Cognitive Ability",
            "skills": ["General cognitive ability", "Numerical reasoning", "Verbal reasoning", "Logical reasoning"],
            "duration": 12,
            "test_type": "A",
        },
        # Personality Tests
        {
            "name": "OPQ32 (Occupational Personality Questionnaire)",
            "url": "https://www.shl.com/solutions/products/assessments/personality-assessment/opq/",
            "description": "The world's leading personality questionnaire for workplace use. Measures 32 personality characteristics linked to work performance across relationships, thinking style, and emotions.",
            "category": "Personality",
            "skills": ["Personality profiling", "Leadership potential", "Team fit", "Workplace behavior", "Emotional resilience"],
            "duration": 25,
            "test_type": "P",
        },
        {
            "name": "MQ (Motivation Questionnaire)",
            "url": "https://www.shl.com/solutions/products/assessments/personality-assessment/motivation-questionnaire/",
            "description": "Assesses 18 motivational factors that increase or decrease energy and enthusiasm for work. Helps understand what drives individual performance.",
            "category": "Personality",
            "skills": ["Motivational fit", "Engagement drivers", "Career alignment", "Job satisfaction predictors"],
            "duration": 25,
            "test_type": "P",
        },
        {
            "name": "Dependability and Safety Instrument (DSI)",
            "url": "https://www.shl.com/solutions/products/assessments/personality-assessment/dependability-safety-instrument/",
            "description": "Identifies counterproductive behaviors and assesses dependability, safety consciousness, and reliability. Used for roles with safety or trust requirements.",
            "category": "Personality",
            "skills": ["Dependability", "Safety awareness", "Reliability", "Integrity"],
            "duration": 20,
            "test_type": "P",
        },
        # Situational Judgement Tests
        {
            "name": "Customer Service Scenarios (CSS)",
            "url": "https://www.shl.com/solutions/products/assessments/situational-judgment/customer-service-scenarios/",
            "description": "Measures judgment in realistic customer service situations. Assesses service orientation, problem resolution, and communication effectiveness.",
            "category": "Situational Judgement",
            "skills": ["Customer service", "Problem resolution", "Communication", "Service orientation"],
            "duration": 20,
            "test_type": "S",
        },
        {
            "name": "Retail Sales Associate Solution",
            "url": "https://www.shl.com/solutions/products/assessments/situational-judgment/retail-sales-associate/",
            "description": "Situational judgement test designed for retail sales roles, assessing how candidates handle typical retail scenarios.",
            "category": "Situational Judgement",
            "skills": ["Sales skills", "Customer interaction", "Retail judgment", "Upselling"],
            "duration": 20,
            "test_type": "S",
        },
        {
            "name": "Manager SJT",
            "url": "https://www.shl.com/solutions/products/assessments/situational-judgment/manager-sjt/",
            "description": "Situational judgment test for managerial roles. Evaluates judgment in leadership, team management, and business decision-making scenarios.",
            "category": "Situational Judgement",
            "skills": ["Leadership judgment", "Team management", "Decision making", "Business acumen"],
            "duration": 30,
            "test_type": "S",
        },
        # Knowledge & Skills Tests
        {
            "name": "Java 8 (New)",
            "url": "https://www.shl.com/solutions/products/assessments/skills-and-knowledge/java-8/",
            "description": "Tests knowledge of Java 8 programming including OOP, collections, streams, lambdas, and core APIs. Suitable for mid-level to senior Java developers.",
            "category": "Technology",
            "skills": ["Java 8", "OOP", "Streams", "Lambda expressions", "Collections framework", "Core Java APIs"],
            "duration": 40,
            "test_type": "K",
        },
        {
            "name": "Python (New)",
            "url": "https://www.shl.com/solutions/products/assessments/skills-and-knowledge/python/",
            "description": "Assesses Python programming skills including syntax, data structures, OOP, and standard libraries. Used for data engineering and software development roles.",
            "category": "Technology",
            "skills": ["Python", "Data structures", "OOP", "Standard libraries", "File I/O", "Error handling"],
            "duration": 40,
            "test_type": "K",
        },
        {
            "name": "SQL (New)",
            "url": "https://www.shl.com/solutions/products/assessments/skills-and-knowledge/sql/",
            "description": "Tests knowledge of SQL including queries, joins, aggregations, subqueries, and database design concepts.",
            "category": "Technology",
            "skills": ["SQL", "Database queries", "Joins", "Aggregations", "Subqueries", "Data manipulation"],
            "duration": 35,
            "test_type": "K",
        },
        {
            "name": "JavaScript (New)",
            "url": "https://www.shl.com/solutions/products/assessments/skills-and-knowledge/javascript/",
            "description": "Evaluates JavaScript programming knowledge including DOM manipulation, async programming, ES6+ features, and frameworks.",
            "category": "Technology",
            "skills": ["JavaScript", "ES6+", "DOM manipulation", "Async programming", "Promises", "Closures"],
            "duration": 40,
            "test_type": "K",
        },
        {
            "name": "C# (New)",
            "url": "https://www.shl.com/solutions/products/assessments/skills-and-knowledge/c-sharp/",
            "description": "Tests C# programming knowledge including .NET framework, OOP principles, LINQ, async/await, and common design patterns.",
            "category": "Technology",
            "skills": ["C#", ".NET", "OOP", "LINQ", "Async programming", "Design patterns"],
            "duration": 40,
            "test_type": "K",
        },
        {
            "name": "C++ (New)",
            "url": "https://www.shl.com/solutions/products/assessments/skills-and-knowledge/cpp/",
            "description": "Assesses C++ programming skills including memory management, STL, OOP, templates, and modern C++ features.",
            "category": "Technology",
            "skills": ["C++", "Memory management", "STL", "OOP", "Templates", "Modern C++"],
            "duration": 40,
            "test_type": "K",
        },
        {
            "name": "React (New)",
            "url": "https://www.shl.com/solutions/products/assessments/skills-and-knowledge/react/",
            "description": "Evaluates knowledge of React framework including components, hooks, state management, and React ecosystem.",
            "category": "Technology",
            "skills": ["React", "Hooks", "Component architecture", "State management", "JSX", "React Router"],
            "duration": 35,
            "test_type": "K",
        },
        {
            "name": "Angular (New)",
            "url": "https://www.shl.com/solutions/products/assessments/skills-and-knowledge/angular/",
            "description": "Tests Angular framework knowledge including components, services, dependency injection, RxJS, and Angular CLI.",
            "category": "Technology",
            "skills": ["Angular", "TypeScript", "RxJS", "Dependency injection", "Angular CLI", "Services"],
            "duration": 35,
            "test_type": "K",
        },
        {
            "name": "Node.js (New)",
            "url": "https://www.shl.com/solutions/products/assessments/skills-and-knowledge/nodejs/",
            "description": "Assesses Node.js development skills including server-side JavaScript, Express, async I/O, and npm ecosystem.",
            "category": "Technology",
            "skills": ["Node.js", "Express", "REST APIs", "Async I/O", "npm", "Server-side JavaScript"],
            "duration": 35,
            "test_type": "K",
        },
        {
            "name": ".NET (New)",
            "url": "https://www.shl.com/solutions/products/assessments/skills-and-knowledge/dotnet/",
            "description": "Tests .NET framework knowledge including ASP.NET, Entity Framework, and C# integration for enterprise development.",
            "category": "Technology",
            "skills": [".NET", "ASP.NET", "Entity Framework", "C#", "Web APIs", "MVC"],
            "duration": 40,
            "test_type": "K",
        },
        {
            "name": "AWS (New)",
            "url": "https://www.shl.com/solutions/products/assessments/skills-and-knowledge/aws/",
            "description": "Evaluates Amazon Web Services knowledge including compute, storage, networking, security, and cloud architecture.",
            "category": "Technology",
            "skills": ["AWS", "EC2", "S3", "Lambda", "Cloud architecture", "IAM", "RDS"],
            "duration": 30,
            "test_type": "K",
        },
        {
            "name": "Azure (New)",
            "url": "https://www.shl.com/solutions/products/assessments/skills-and-knowledge/azure/",
            "description": "Tests Microsoft Azure cloud platform knowledge including services, architecture, security, and DevOps integration.",
            "category": "Technology",
            "skills": ["Azure", "Azure DevOps", "Cloud architecture", "Azure Functions", "Azure AD"],
            "duration": 30,
            "test_type": "K",
        },
        {
            "name": "Data Analysis",
            "url": "https://www.shl.com/solutions/products/assessments/skills-and-knowledge/data-analysis/",
            "description": "Assesses ability to interpret and analyze data using statistical techniques, visualization, and data manipulation skills.",
            "category": "Technology",
            "skills": ["Data analysis", "Statistics", "Data visualization", "Excel", "SQL", "Analytical thinking"],
            "duration": 35,
            "test_type": "K",
        },
        {
            "name": "Machine Learning (New)",
            "url": "https://www.shl.com/solutions/products/assessments/skills-and-knowledge/machine-learning/",
            "description": "Tests knowledge of machine learning concepts, algorithms, model evaluation, and practical ML implementation.",
            "category": "Technology",
            "skills": ["Machine learning", "Supervised learning", "Model evaluation", "Feature engineering", "Python", "scikit-learn"],
            "duration": 40,
            "test_type": "K",
        },
        {
            "name": "Automata - Fix the Code",
            "url": "https://www.shl.com/solutions/products/assessments/skills-and-knowledge/automata-fix-the-code/",
            "description": "A hands-on coding assessment where candidates fix broken code snippets across multiple languages. Tests debugging, code comprehension, and problem-solving.",
            "category": "Technology",
            "skills": ["Debugging", "Code comprehension", "Problem solving", "Multiple languages"],
            "duration": 30,
            "test_type": "K",
        },
        {
            "name": "Automata Pro",
            "url": "https://www.shl.com/solutions/products/assessments/skills-and-knowledge/automata-pro/",
            "description": "Advanced coding simulation platform for software engineers. Tests real-world coding ability in a full development environment.",
            "category": "Technology",
            "skills": ["Software engineering", "Algorithms", "Data structures", "Coding", "Problem solving"],
            "duration": 60,
            "test_type": "K",
        },
        {
            "name": "Technology Professional 8.0",
            "url": "https://www.shl.com/solutions/products/assessments/skills-and-knowledge/technology-professional/",
            "description": "Comprehensive assessment for technology professionals covering multiple IT domains including networking, security, and systems.",
            "category": "Technology",
            "skills": ["IT fundamentals", "Networking", "Security", "Systems administration", "Technology concepts"],
            "duration": 45,
            "test_type": "K",
        },
        {
            "name": "Microsoft Excel (New)",
            "url": "https://www.shl.com/solutions/products/assessments/skills-and-knowledge/microsoft-excel/",
            "description": "Tests practical Excel skills including formulas, pivot tables, data analysis, and spreadsheet management.",
            "category": "Business Skills",
            "skills": ["Excel", "Formulas", "Pivot tables", "Data analysis", "Spreadsheets", "VBA basics"],
            "duration": 30,
            "test_type": "K",
        },
        {
            "name": "Microsoft Word (New)",
            "url": "https://www.shl.com/solutions/products/assessments/skills-and-knowledge/microsoft-word/",
            "description": "Evaluates Microsoft Word proficiency including formatting, styles, mail merge, and document creation.",
            "category": "Business Skills",
            "skills": ["Microsoft Word", "Document formatting", "Styles", "Mail merge", "Templates"],
            "duration": 25,
            "test_type": "K",
        },
        {
            "name": "Accounting and Finance (New)",
            "url": "https://www.shl.com/solutions/products/assessments/skills-and-knowledge/accounting-finance/",
            "description": "Tests knowledge of accounting principles, financial statements, budgeting, and financial analysis for finance roles.",
            "category": "Finance",
            "skills": ["Accounting", "Financial statements", "Budgeting", "Financial analysis", "GAAP"],
            "duration": 35,
            "test_type": "K",
        },
        {
            "name": "Sales Representative Solution",
            "url": "https://www.shl.com/solutions/products/assessments/skills-and-knowledge/sales-representative/",
            "description": "Assesses core sales competencies including prospecting, objection handling, negotiation, and closing skills.",
            "category": "Sales",
            "skills": ["Sales techniques", "Prospecting", "Objection handling", "Negotiation", "CRM knowledge"],
            "duration": 30,
            "test_type": "K",
        },
        {
            "name": "Contact Center Solution",
            "url": "https://www.shl.com/solutions/products/assessments/skills-and-knowledge/contact-center/",
            "description": "Designed for contact center roles. Tests customer service skills, call handling, empathy, and problem resolution.",
            "category": "Customer Service",
            "skills": ["Call handling", "Customer empathy", "Problem resolution", "Active listening", "Multi-tasking"],
            "duration": 25,
            "test_type": "K",
        },
        {
            "name": "Administrative Professional 8.0",
            "url": "https://www.shl.com/solutions/products/assessments/skills-and-knowledge/administrative-professional/",
            "description": "Comprehensive assessment for administrative roles covering organizational skills, communication, computer proficiency, and office management.",
            "category": "Business Skills",
            "skills": ["Organization", "Communication", "Computer skills", "Office management", "Scheduling"],
            "duration": 35,
            "test_type": "K",
        },
        {
            "name": "Occupational English Test",
            "url": "https://www.shl.com/solutions/products/assessments/skills-and-knowledge/occupational-english/",
            "description": "Tests English language proficiency in a workplace context including reading, writing, listening, and speaking skills.",
            "category": "Language",
            "skills": ["English proficiency", "Business writing", "Reading comprehension", "Listening", "Communication"],
            "duration": 45,
            "test_type": "K",
        },
        {
            "name": "Business English Test",
            "url": "https://www.shl.com/solutions/products/assessments/skills-and-knowledge/business-english/",
            "description": "Evaluates business English skills including grammar, vocabulary, email writing, and professional communication.",
            "category": "Language",
            "skills": ["Business English", "Grammar", "Professional writing", "Vocabulary", "Email etiquette"],
            "duration": 30,
            "test_type": "K",
        },
        {
            "name": "Cybersecurity (New)",
            "url": "https://www.shl.com/solutions/products/assessments/skills-and-knowledge/cybersecurity/",
            "description": "Assesses cybersecurity knowledge including threat detection, network security, vulnerability assessment, and security protocols.",
            "category": "Technology",
            "skills": ["Cybersecurity", "Network security", "Threat detection", "Vulnerability assessment", "Security protocols"],
            "duration": 40,
            "test_type": "K",
        },
        {
            "name": "DevOps (New)",
            "url": "https://www.shl.com/solutions/products/assessments/skills-and-knowledge/devops/",
            "description": "Tests DevOps knowledge and practices including CI/CD pipelines, containerization, infrastructure as code, and monitoring.",
            "category": "Technology",
            "skills": ["DevOps", "CI/CD", "Docker", "Kubernetes", "Infrastructure as code", "Monitoring"],
            "duration": 35,
            "test_type": "K",
        },
        {
            "name": "Agile Software Development",
            "url": "https://www.shl.com/solutions/products/assessments/skills-and-knowledge/agile/",
            "description": "Evaluates understanding of Agile methodologies including Scrum, Kanban, sprint planning, and Agile principles.",
            "category": "Technology",
            "skills": ["Agile", "Scrum", "Kanban", "Sprint planning", "User stories", "Retrospectives"],
            "duration": 25,
            "test_type": "K",
        },
        {
            "name": "Logical Thinking",
            "url": "https://www.shl.com/solutions/products/assessments/cognitive-assessments/logical-thinking/",
            "description": "Measures logical reasoning ability including syllogisms, logical sequences, and structured thinking. Used across many professional roles.",
            "category": "Cognitive Ability",
            "skills": ["Logical reasoning", "Critical thinking", "Syllogistic reasoning", "Structured thinking"],
            "duration": 20,
            "test_type": "A",
        },
        {
            "name": "Numerical Reasoning 1",
            "url": "https://www.shl.com/solutions/products/assessments/cognitive-assessments/numerical-reasoning-1/",
            "description": "Entry-level numerical reasoning test for roles requiring basic mathematical comprehension and data analysis skills.",
            "category": "Cognitive Ability",
            "skills": ["Basic numeracy", "Arithmetic", "Data tables", "Percentage calculations"],
            "duration": 25,
            "test_type": "A",
        },
        {
            "name": "Graduate Numerical Reasoning",
            "url": "https://www.shl.com/solutions/products/assessments/cognitive-assessments/graduate-numerical-reasoning/",
            "description": "Numerical reasoning assessment designed for graduate-level positions. Tests ability to interpret complex data and make business decisions.",
            "category": "Cognitive Ability",
            "skills": ["Advanced numeracy", "Financial data", "Statistical analysis", "Business data interpretation"],
            "duration": 25,
            "test_type": "A",
        },
        {
            "name": "Workplace English Test",
            "url": "https://www.shl.com/solutions/products/assessments/skills-and-knowledge/workplace-english/",
            "description": "Tests workplace-relevant English skills across reading, writing, and comprehension for non-native speakers.",
            "category": "Language",
            "skills": ["English language", "Workplace communication", "Reading", "Writing", "Comprehension"],
            "duration": 35,
            "test_type": "K",
        },
        {
            "name": "Situational Judgement for Graduates",
            "url": "https://www.shl.com/solutions/products/assessments/situational-judgment/sjt-graduates/",
            "description": "Situational judgement test tailored for graduate assessment centers. Evaluates professional judgment in workplace scenarios.",
            "category": "Situational Judgement",
            "skills": ["Professional judgment", "Workplace scenarios", "Decision making", "Graduate competencies"],
            "duration": 25,
            "test_type": "S",
        },
        {
            "name": "PHP (New)",
            "url": "https://www.shl.com/solutions/products/assessments/skills-and-knowledge/php/",
            "description": "Assesses PHP web development skills including syntax, OOP, frameworks, and database integration.",
            "category": "Technology",
            "skills": ["PHP", "OOP", "Web development", "Laravel", "MySQL integration", "RESTful APIs"],
            "duration": 35,
            "test_type": "K",
        },
        {
            "name": "Scala (New)",
            "url": "https://www.shl.com/solutions/products/assessments/skills-and-knowledge/scala/",
            "description": "Tests Scala programming knowledge including functional programming, Akka, and Spark for big data roles.",
            "category": "Technology",
            "skills": ["Scala", "Functional programming", "Akka", "Apache Spark", "Big data"],
            "duration": 40,
            "test_type": "K",
        },
        {
            "name": "Kotlin (New)",
            "url": "https://www.shl.com/solutions/products/assessments/skills-and-knowledge/kotlin/",
            "description": "Evaluates Kotlin programming for Android and backend development including coroutines, extensions, and interoperability.",
            "category": "Technology",
            "skills": ["Kotlin", "Android development", "Coroutines", "Extension functions", "Java interop"],
            "duration": 35,
            "test_type": "K",
        },
        {
            "name": "Swift (New)",
            "url": "https://www.shl.com/solutions/products/assessments/skills-and-knowledge/swift/",
            "description": "Assesses Swift programming for iOS development including protocols, closures, SwiftUI, and Xcode.",
            "category": "Technology",
            "skills": ["Swift", "iOS development", "SwiftUI", "Protocols", "Closures", "Xcode"],
            "duration": 35,
            "test_type": "K",
        },
        {
            "name": "Ruby (New)",
            "url": "https://www.shl.com/solutions/products/assessments/skills-and-knowledge/ruby/",
            "description": "Tests Ruby programming including Rails framework, metaprogramming, blocks, and web development patterns.",
            "category": "Technology",
            "skills": ["Ruby", "Ruby on Rails", "Metaprogramming", "Web development", "ActiveRecord"],
            "duration": 35,
            "test_type": "K",
        },
        {
            "name": "Go (Golang) (New)",
            "url": "https://www.shl.com/solutions/products/assessments/skills-and-knowledge/go/",
            "description": "Evaluates Go programming skills including goroutines, channels, interfaces, and standard library for backend and systems development.",
            "category": "Technology",
            "skills": ["Go", "Goroutines", "Channels", "Interfaces", "Concurrency", "Standard library"],
            "duration": 35,
            "test_type": "K",
        },
        {
            "name": "R Programming (New)",
            "url": "https://www.shl.com/solutions/products/assessments/skills-and-knowledge/r-programming/",
            "description": "Tests R programming for data analysis and statistics including ggplot2, dplyr, tidyverse, and statistical modeling.",
            "category": "Technology",
            "skills": ["R programming", "ggplot2", "dplyr", "Statistical modeling", "Data visualization", "tidyverse"],
            "duration": 35,
            "test_type": "K",
        },
        {
            "name": "Git (New)",
            "url": "https://www.shl.com/solutions/products/assessments/skills-and-knowledge/git/",
            "description": "Assesses Git version control knowledge including branching, merging, rebasing, and collaborative workflows.",
            "category": "Technology",
            "skills": ["Git", "Version control", "Branching", "Merging", "Pull requests", "CI/CD integration"],
            "duration": 20,
            "test_type": "K",
        },
        {
            "name": "Project Management Professional",
            "url": "https://www.shl.com/solutions/products/assessments/skills-and-knowledge/project-management/",
            "description": "Tests project management knowledge including planning, risk management, stakeholder communication, and PM methodologies.",
            "category": "Business Skills",
            "skills": ["Project management", "Risk management", "Stakeholder communication", "Agile", "PMP concepts"],
            "duration": 35,
            "test_type": "K",
        },
        {
            "name": "Graduate 8.0 (SHL Verify)",
            "url": "https://www.shl.com/solutions/products/assessments/cognitive-assessments/graduate/",
            "description": "Comprehensive cognitive battery for graduate-level hiring including numerical, verbal, and inductive reasoning.",
            "category": "Cognitive Ability",
            "skills": ["Numerical reasoning", "Verbal reasoning", "Inductive reasoning", "Graduate-level thinking"],
            "duration": 58,
            "test_type": "A",
        },
        {
            "name": "Entry Level 7.0 (SHL Verify)",
            "url": "https://www.shl.com/solutions/products/assessments/cognitive-assessments/entry-level/",
            "description": "Cognitive ability battery for entry-level positions including basic numerical and verbal reasoning.",
            "category": "Cognitive Ability",
            "skills": ["Basic reasoning", "Entry-level numeracy", "Reading comprehension"],
            "duration": 35,
            "test_type": "A",
        },
        {
            "name": "Supervisory 7.0 (SHL Verify)",
            "url": "https://www.shl.com/solutions/products/assessments/cognitive-assessments/supervisory/",
            "description": "Cognitive battery designed for supervisory and team lead roles, measuring reasoning and decision-making ability.",
            "category": "Cognitive Ability",
            "skills": ["Supervisory reasoning", "Decision making", "Numerical analysis", "Verbal comprehension"],
            "duration": 40,
            "test_type": "A",
        },
    ]
    return assessments


def run_scraper() -> list[dict]:
    """Main scraper function. Returns list of assessment dictionaries."""
    logger.info("Starting SHL catalog scraping...")

    # Try to fetch the live catalog first
    soup = fetch_page(CATALOG_URL)
    assessments = []

    if soup:
        logger.info("Successfully fetched catalog page, attempting parse...")
        items = parse_catalog_page(soup)

        if items:
            logger.info(f"Found {len(items)} items, fetching detail pages...")
            for item in items[:50]:  # limit to avoid rate limiting
                details = scrape_product_page(item["url"])
                item.update(details)
                if "test_type" not in item or not item["test_type"]:
                    item["test_type"] = infer_test_type(
                        item.get("name", ""),
                        item.get("description", ""),
                        item.get("category", ""),
                    )
                assessments.append(item)
                time.sleep(0.5)

    # Use curated data if scraping yields insufficient results
    if len(assessments) < 10:
        logger.info("Using curated catalog data (scraping yielded insufficient results)")
        assessments = build_catalog_from_known_data()

    logger.info(f"Final catalog: {len(assessments)} assessments")
    return assessments


def save_catalog(assessments: list[dict]) -> None:
    """Save catalog to JSON file."""
    OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
        json.dump(assessments, f, indent=2, ensure_ascii=False)
    logger.info(f"Catalog saved to {OUTPUT_PATH}")


if __name__ == "__main__":
    assessments = run_scraper()
    save_catalog(assessments)
    print(f"\n✅ Scraped {len(assessments)} assessments")
    print(f"📁 Saved to {OUTPUT_PATH}")
