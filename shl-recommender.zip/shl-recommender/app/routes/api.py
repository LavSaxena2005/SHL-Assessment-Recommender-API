"""
FastAPI route definitions for the SHL Recommender API.
"""

import logging
from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import JSONResponse

from app.models.schemas import ChatRequest, ChatResponse, HealthResponse
from app.services.conversation import process_chat

logger = logging.getLogger(__name__)

router = APIRouter()


@router.get("/health", response_model=HealthResponse, tags=["health"])
async def health_check() -> HealthResponse:
    """Health check endpoint."""
    return HealthResponse(status="ok")


@router.post("/chat", response_model=ChatResponse, tags=["chat"])
async def chat(request: ChatRequest) -> ChatResponse:
    """
    Process a conversational message and return SHL assessment recommendations.

    The request must contain the full conversation history (stateless API).
    The last message must be from the user role.

    Returns:
        - reply: Natural language response
        - recommendations: List of validated SHL assessments ([] when clarifying)
        - end_of_conversation: True when the conversation should conclude
    """
    try:
        response = process_chat(request)
        return response
    except ValueError as e:
        logger.warning(f"Validation error: {e}")
        raise HTTPException(status_code=422, detail=str(e))
    except Exception as e:
        logger.error(f"Unexpected error in /chat: {e}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail="Internal server error. Please try again.",
        )
