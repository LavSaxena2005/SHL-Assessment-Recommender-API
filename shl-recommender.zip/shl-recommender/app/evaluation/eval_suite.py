"""
Evaluation Suite for SHL Assessment Recommender
Tests: Recall@10, groundedness, hallucination rate, behavioral probes
"""

import json
import logging
import time
from pathlib import Path
from typing import Optional
import sys

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

CATALOG_PATH = Path(__file__).parent.parent / "catalog" / "catalog.json"


# ─── TEST DATA ────────────────────────────────────────────────────────────────

RETRIEVAL_TEST_CASES = [
    {
        "query": "Java developer backend engineer",
        "expected_names": ["Java 8 (New)", "Python (New)", "SQL (New)", "Automata Pro"],
        "description": "Java backend developer query",
    },
    {
        "query": "personality assessment leadership manager",
        "expected_names": ["OPQ32 (Occupational Personality Questionnaire)", "Manager SJT", "MQ (Motivation Questionnaire)"],
        "description": "Manager personality assessment",
    },
    {
        "query": "numerical reasoning graduate analyst",
        "expected_names": [
            "Verify Numerical Reasoning",
            "Graduate Numerical Reasoning",
            "Graduate 8.0 (SHL Verify)",
        ],
        "description": "Graduate numerical reasoning",
    },
    {
        "query": "customer service call center support",
        "expected_names": ["Customer Service Scenarios (CSS)", "Contact Center Solution"],
        "description": "Customer service role",
    },
    {
        "query": "data scientist python machine learning",
        "expected_names": ["Python (New)", "Machine Learning (New)", "R Programming (New)", "Data Analysis"],
        "description": "Data scientist query",
    },
    {
        "query": "software engineer coding debugging",
        "expected_names": ["Automata Pro", "Automata - Fix the Code"],
        "description": "Coding assessment query",
    },
    {
        "query": "verbal reasoning communication writing",
        "expected_names": ["Verify Verbal Reasoning"],
        "description": "Verbal reasoning query",
    },
    {
        "query": "cloud AWS DevOps infrastructure",
        "expected_names": ["AWS (New)", "DevOps (New)", "Azure (New)"],
        "description": "Cloud/DevOps query",
    },
    {
        "query": "sales representative retail",
        "expected_names": ["Sales Representative Solution", "Retail Sales Associate Solution"],
        "description": "Sales role query",
    },
    {
        "query": "attention to detail accuracy data entry",
        "expected_names": ["Verify Checking", "Administrative Professional 8.0"],
        "description": "Accuracy/checking query",
    },
]

BEHAVIORAL_TEST_CASES = [
    {
        "id": "clarify_vague",
        "messages": [{"role": "user", "content": "I need an assessment"}],
        "expected_intent": "clarify",
        "expected_empty_recs": True,
        "description": "Vague query should trigger clarification",
    },
    {
        "id": "recommend_java",
        "messages": [
            {"role": "user", "content": "Hiring Java backend developer, mid-level, 3 years experience"},
        ],
        "expected_intent": "recommend",
        "expected_has_recs": True,
        "description": "Specific Java dev query should get recommendations",
    },
    {
        "id": "refuse_competitor",
        "messages": [
            {"role": "user", "content": "Tell me about Hogan personality tests"},
        ],
        "expected_intent": "refuse",
        "expected_empty_recs": True,
        "description": "Competitor product should be refused",
    },
    {
        "id": "refuse_general_advice",
        "messages": [
            {"role": "user", "content": "What salary should I offer a software engineer?"},
        ],
        "expected_intent": "refuse",
        "expected_empty_recs": True,
        "description": "Off-topic question should be refused",
    },
    {
        "id": "refine_add_personality",
        "messages": [
            {"role": "user", "content": "Hiring Python developer"},
            {"role": "assistant", "content": '{"intent":"recommend","reply":"Here are Python assessments","recommendation_names":["Python (New)"]}'},
            {"role": "user", "content": "Also add a personality test"},
        ],
        "expected_intent": "refine",
        "expected_has_recs": True,
        "description": "Refinement should add personality assessment",
    },
    {
        "id": "compare_assessments",
        "messages": [
            {"role": "user", "content": "What is the difference between OPQ32 and MQ?"},
        ],
        "expected_intent": "compare",
        "description": "Comparison of two assessments",
    },
]


# ─── RECALL@K EVALUATION ─────────────────────────────────────────────────────

def evaluate_recall_at_k(k: int = 10) -> dict:
    """
    Evaluate Recall@K for the hybrid retriever.
    Returns metrics per test case and overall recall.
    """
    from app.retriever.hybrid_retriever import get_retriever

    retriever = get_retriever()
    results = []
    total_recall = 0.0

    for tc in RETRIEVAL_TEST_CASES:
        query = tc["query"]
        expected = set(tc["expected_names"])

        retrieved = retriever.retrieve(query, top_k=k)
        retrieved_names = {r["name"] for r in retrieved}

        hits = expected & retrieved_names
        recall = len(hits) / len(expected) if expected else 0.0
        total_recall += recall

        result = {
            "query": query,
            "description": tc["description"],
            "expected": list(expected),
            "retrieved": [r["name"] for r in retrieved[:5]],
            "hits": list(hits),
            "recall": round(recall, 3),
        }
        results.append(result)

        status = "✅" if recall >= 0.5 else "⚠️" if recall > 0 else "❌"
        logger.info(f"{status} Recall={recall:.2f} | {tc['description']}")

    mean_recall = total_recall / len(RETRIEVAL_TEST_CASES)

    return {
        "metric": f"Recall@{k}",
        "mean_recall": round(mean_recall, 3),
        "test_cases": results,
        "passed": sum(1 for r in results if r["recall"] >= 0.5),
        "total": len(results),
    }


# ─── GROUNDEDNESS EVALUATION ─────────────────────────────────────────────────

def evaluate_groundedness(api_url: str = "http://localhost:8000") -> dict:
    """
    Test that all returned recommendations exist in the catalog.
    Groundedness = 100% of returned assessments are in catalog.
    """
    import requests

    catalog = json.loads(CATALOG_PATH.read_text())
    catalog_names = {a["name"].lower() for a in catalog}
    catalog_urls = {a.get("url", "").lower() for a in catalog}

    results = []
    hallucination_count = 0

    test_queries = [
        {"messages": [{"role": "user", "content": "Hiring Java developer mid-level backend"}]},
        {"messages": [{"role": "user", "content": "Need personality test for leadership role"}]},
        {"messages": [{"role": "user", "content": "Graduate cognitive assessment"}]},
        {"messages": [{"role": "user", "content": "Python data scientist assessment"}]},
        {"messages": [{"role": "user", "content": "Customer service agent hiring"}]},
    ]

    for query in test_queries:
        try:
            resp = requests.post(f"{api_url}/chat", json=query, timeout=30)
            if resp.status_code != 200:
                continue
            data = resp.json()
            recs = data.get("recommendations", [])

            for rec in recs:
                name = rec.get("name", "").lower()
                url = rec.get("url", "").lower()
                in_catalog = name in catalog_names

                if not in_catalog:
                    hallucination_count += 1
                    logger.warning(f"HALLUCINATION: '{rec['name']}' not in catalog!")

                results.append({
                    "query": query["messages"][0]["content"],
                    "name": rec["name"],
                    "grounded": in_catalog,
                })
        except Exception as e:
            logger.error(f"Error during groundedness test: {e}")

    grounded = sum(1 for r in results if r["grounded"])
    groundedness_rate = grounded / len(results) if results else 0.0

    return {
        "metric": "groundedness",
        "groundedness_rate": round(groundedness_rate, 3),
        "hallucinations": hallucination_count,
        "total_recommendations": len(results),
        "grounded_recommendations": grounded,
    }


# ─── BEHAVIORAL PROBE EVALUATION ─────────────────────────────────────────────

def evaluate_behavioral_probes(api_url: str = "http://localhost:8000") -> dict:
    """
    Test that the system behaves correctly for different intents.
    """
    import requests

    results = []

    for tc in BEHAVIORAL_TEST_CASES:
        try:
            payload = {"messages": tc["messages"]}
            resp = requests.post(f"{api_url}/chat", json=payload, timeout=30)

            if resp.status_code != 200:
                results.append({
                    "id": tc["id"],
                    "description": tc["description"],
                    "passed": False,
                    "reason": f"HTTP {resp.status_code}",
                })
                continue

            data = resp.json()
            recs = data.get("recommendations", [])
            reply = data.get("reply", "")

            passed = True
            reason = "ok"

            # Validate expected_empty_recs
            if tc.get("expected_empty_recs") and recs:
                passed = False
                reason = f"Expected no recommendations, got {len(recs)}"

            # Validate expected_has_recs
            if tc.get("expected_has_recs") and not recs:
                passed = False
                reason = "Expected recommendations, got none"

            status = "✅" if passed else "❌"
            logger.info(f"{status} [{tc['id']}] {tc['description']} | {reason}")
            logger.info(f"   Reply: {reply[:100]}...")

            results.append({
                "id": tc["id"],
                "description": tc["description"],
                "passed": passed,
                "reason": reason,
                "recommendations_count": len(recs),
                "reply_preview": reply[:100],
            })

        except Exception as e:
            logger.error(f"Error in probe {tc['id']}: {e}")
            results.append({
                "id": tc["id"],
                "description": tc["description"],
                "passed": False,
                "reason": str(e),
            })

    passed_count = sum(1 for r in results if r["passed"])
    return {
        "metric": "behavioral_probes",
        "passed": passed_count,
        "total": len(results),
        "pass_rate": round(passed_count / len(results), 3) if results else 0,
        "results": results,
    }


# ─── FULL EVALUATION RUNNER ──────────────────────────────────────────────────

def run_all_evaluations(api_url: Optional[str] = None) -> dict:
    """Run all evaluations and produce a comprehensive report."""
    logger.info("=" * 60)
    logger.info("SHL Recommender Evaluation Suite")
    logger.info("=" * 60)

    report = {}

    # 1. Recall@10
    logger.info("\n📊 Running Recall@10 Evaluation...")
    recall_results = evaluate_recall_at_k(k=10)
    report["recall_at_10"] = recall_results
    logger.info(f"Mean Recall@10: {recall_results['mean_recall']:.3f}")

    # 2. Behavioral + Groundedness (require running API)
    if api_url:
        logger.info("\n🎯 Running Groundedness Evaluation...")
        groundedness = evaluate_groundedness(api_url)
        report["groundedness"] = groundedness
        logger.info(f"Groundedness Rate: {groundedness['groundedness_rate']:.3f}")

        logger.info("\n🔬 Running Behavioral Probe Evaluation...")
        behavioral = evaluate_behavioral_probes(api_url)
        report["behavioral_probes"] = behavioral
        logger.info(f"Behavioral Pass Rate: {behavioral['pass_rate']:.3f}")
    else:
        logger.info("\n⚠️  Skipping API-dependent evaluations (no api_url provided)")
        logger.info("   Run with: python -m app.evaluation.eval_suite http://localhost:8000")

    # Summary
    logger.info("\n" + "=" * 60)
    logger.info("EVALUATION SUMMARY")
    logger.info("=" * 60)
    logger.info(f"Recall@10:      {recall_results['mean_recall']:.3f}")
    if "groundedness" in report:
        logger.info(f"Groundedness:   {report['groundedness']['groundedness_rate']:.3f}")
    if "behavioral_probes" in report:
        logger.info(f"Behavioral:     {report['behavioral_probes']['pass_rate']:.3f}")

    return report


if __name__ == "__main__":
    api_url = sys.argv[1] if len(sys.argv) > 1 else None
    report = run_all_evaluations(api_url)

    output_path = Path(__file__).parent / "eval_report.json"
    with open(output_path, "w") as f:
        json.dump(report, f, indent=2)
    logger.info(f"\n📄 Report saved to {output_path}")
