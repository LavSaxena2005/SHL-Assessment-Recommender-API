"""
SHL Assessment Recommender API
Main FastAPI application entry point.
"""

import logging
import os
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.routes.api import router
from app.retriever.hybrid_retriever import get_retriever

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup: pre-load retrieval indexes to reduce first-request latency."""
    logger.info("Starting SHL Recommender API...")
    logger.info("Pre-loading retrieval indexes...")
    retriever = get_retriever()
    logger.info(f"Retriever ready with {len(retriever.get_all())} assessments")
    yield
    logger.info("Shutting down SHL Recommender API")


app = FastAPI(
    title="SHL Assessment Recommender API",
    description=(
        "Conversational AI system for discovering SHL Individual Test Solutions. "
        "Uses hybrid RAG (BM25 + semantic) retrieval with GPT-4o-mini generation."
    ),
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
)

# CORS — configure for your deployment
app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("ALLOWED_ORIGINS", "*").split(","),
    allow_credentials=True,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

# Include routes
app.include_router(router)


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=int(os.getenv("PORT", 8000)),
        reload=os.getenv("ENV", "production") == "development",
        log_level="info",
    )
